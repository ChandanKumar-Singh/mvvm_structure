import 'package:device_preview/device_preview.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '/utils/my_logger.dart';
import 'screens/dashboard/view/basic_page.dart';

void main() {
  runApp(
    DevicePreview(
      enabled: kDebugMode,
      tools: const [
        ...DevicePreview.defaultTools,
        CustomPlugin(),
      ],
      builder: (context) => const BasicApp(),
    ),
  );
}

class CustomPlugin extends StatelessWidget {
  const CustomPlugin({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ToolPanelSection(
      title: 'Custom',
      children: [
        ListTile(
          title: const Text('Print in console'),
          onTap: () {
            // ignore: avoid_print
            print('Hey, this is a custom plugin!');
          },
        )
      ],
    );
  }
}
