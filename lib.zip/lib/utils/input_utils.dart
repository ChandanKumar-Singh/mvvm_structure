// input format functions,

class InputUtils{

  // global validators for email, amount, dynamic


  // global decoration for input fields

}