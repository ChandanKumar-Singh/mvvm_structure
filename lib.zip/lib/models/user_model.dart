abstract class UserModel {
  String id;
  String? token;
  UserModel({required this.id, this.token});
}
