const kFlexMultiplier = 1000.0;
